﻿namespace ExOfOutParameter
{
    class Sample
    {
        public void Method1(out int x)
        {
            x = 150;

            System.Console.WriteLine(x); //Output: 150

        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Sample s;
            s = new Sample();
            int a;
            s.Method1(out a);
            System.Console.WriteLine(a); //Output: 150
            System.Console.ReadKey();

        }
    }
}
