﻿namespace ParamsExample
{
    class Sample
    {
        public void Method1(int x)
        {
            System.Console.WriteLine("value before calling");
            System.Console.WriteLine(x); //Output: 100
            x = 150;
            System.Console.WriteLine("value after calling");
            System.Console.WriteLine(x); //Output: 150
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Sample s1 = new Sample();
            int a = 100;
            s1.Method1(a);

        }
    }
}
