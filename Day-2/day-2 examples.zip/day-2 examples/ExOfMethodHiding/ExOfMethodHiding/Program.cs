﻿using System.Reflection;
using System;

namespace ExOfMethodHiding
{
//parent class
class Person
{
//Fields of "Person" class
public string PersonName; 
public string Gender;

//Person.Display
public void Display()
{
    System.Console.WriteLine("Person Name: " + PersonName); 
    System.Console.WriteLine("Gender: " + Gender);
}
}
//child class 1
class Student : Person
{
    public int StudentID;
    public int Marks;
    //Student.Display
    //Method Hiding: This method hides the parent class's method called "Display". Both methods are having the same signature; but code is different.
    public new void Display()
    {
        System.Console.WriteLine("Student Name: " + PersonName); 
        System.Console.WriteLine("Gender: " + Gender);
        System.Console.WriteLine("Student ID: " + StudentID); 
        System.Console.WriteLine("Student Marks: " + Marks);
    }
}
//child class 2
class Employee : Person
{
    public int EmpID; 
    public double Salary;

    //Employee.Display
    //Method Hiding: This method hides the parent class's method called "Display". Both methods are having the same signature; but code is different.
    public new void Display()
    {
        System.Console.WriteLine("Employee Name: " + PersonName); 
        System.Console.WriteLine("Gender: " + Gender);
        System.Console.WriteLine("Employee ID: " + EmpID); 
        System.Console.WriteLine("Employee Salary: " + Salary);
    }
}

class Program
    {
        static void Main(string[] args)
        {
            /********* creating object for child class 1 *************/
            Student s;

            s = new Student();
            s.PersonName = "Allen";
            s.Gender = "Male";
            s.StudentID = 101;
            s.Marks = 70;
            s.Display(); //calls Student.Display only
            System.Console.WriteLine();
            /********* creating object for child class 2 *************/
            Employee emp;
            emp = new Employee(); 
            emp.PersonName = "Jones"; 
            emp.Gender = "Male"; 
            emp.EmpID = 201;
            emp.Salary = 5000;
            emp.Display(); //calls Employee.Display only
            System.Console.ReadKey();

        }
    }
}
