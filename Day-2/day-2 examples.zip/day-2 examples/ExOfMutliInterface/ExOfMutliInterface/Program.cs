﻿using System.ComponentModel;
using static System.Net.Mime.MediaTypeNames;

namespace ExOfMutliInterface
{
    //Interface example
    interface ICar
    {
        void DisplayModel();

    }
    class Honda : ICar
    { 
        public void DisplayModel() 
        {
            Console.WriteLine("The Model is Honda City");
        }
    }

    //EXAMPLE OF MUltilevel Interface
    interface Ifirst
    {
         void AddNumbers(int x, int y);
    }

    interface ISecond
    {
         void AddNumbers(int x, int y);
    }

    class Sample:Ifirst,ISecond
    {
        void Ifirst.AddNumbers(int x, int y)
        {
            int z;
            z = x + y;
            Console.WriteLine("Result of Add From First Interface  " + z.ToString());
            Console.ReadLine();
        }

        void ISecond.AddNumbers(int x, int y)
        {
            int z;
            z = x + y;
            Console.WriteLine("Result of Add From Second Interface  " + z.ToString());
            Console.ReadLine();
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
             Honda h = new Honda();
            h.DisplayModel();

            /******************/
            Ifirst obj1 = new Sample();
            obj1.AddNumbers(10, 10);

            ISecond obj2 = new Sample();
            obj2.AddNumbers(50, 50);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
