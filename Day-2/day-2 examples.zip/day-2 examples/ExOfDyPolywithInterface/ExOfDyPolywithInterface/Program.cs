﻿namespace ExOfDyPolywithInterface
{
    //interface
    interface IAnimal
    {
        //properties
        string Name { get; set; }
        string breed { get; set; }

        //abstract method
        void AnimalDetails();
    }

    //child class 1
    class Dog : IAnimal

    {
        //properties
        public string Name  { get; set; }
        public string breed { get; set; }

        //implementing the IPerson.Display method 
        public void AnimalDetails()
        {
            System.Console.WriteLine("Animal Name: " + Name);
            System.Console.WriteLine("Breed: " + breed);
        }
    }

    //child class 2
    class Cat : IAnimal
    {
        //properties
        public string Name { get; set; }
        public string breed { get; set; }

        //implementing the IAnimal.animalDetails method 
        public void AnimalDetails()
        {
            System.Console.WriteLine(" Name: " + Name); 
            System.Console.WriteLine("breed: " + breed);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //create reference variable of interface type
            IAnimal a;

            /************* creating object for child class 1 ***************/
            a = new Dog();

            a.Name = "Dicky";
            a.breed = "Beagle";
            a.AnimalDetails(); //calls Dog.AnimalDetails
            System.Console.WriteLine("\n");

            /************* creating object for child class 2 ***************/
            a = new Cat();
            a.Name = "Pony";
            a.breed = "Persian Cat";
            a.AnimalDetails(); //calls Cat.AnimalDetails
            System.Console.ReadKey();
        }
    }
}
