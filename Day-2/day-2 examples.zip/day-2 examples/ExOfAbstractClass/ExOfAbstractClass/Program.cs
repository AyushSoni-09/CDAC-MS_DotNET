﻿namespace ExOfAbstractClass
{
    public abstract class CDAC
    {
        public CDAC()
        {
            Console.WriteLine("Wel Come To C-DAC");
            Console.ReadLine();
        }
        public void Courses()
        {
            Console.WriteLine("We Teach .Net Courses");
            Console.ReadLine();
        }
    }
    public class Employee : CDAC
    {
        public void Work()
        {
            Console.WriteLine("I Work As Scientist In CDAC");
            Console.ReadLine();
        }
        public void Address()
        {
            Console.WriteLine("We Work At Electronic City ,Bangalore");
            Console.ReadLine();
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
                Employee obj = new Employee();
                //CDAC obj1 = new CDAC(); cannot create instance of abstract class
                obj.Courses();
                obj.Work();
                obj.Address();


            }
        }
}
