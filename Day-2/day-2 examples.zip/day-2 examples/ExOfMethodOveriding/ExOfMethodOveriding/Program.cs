﻿namespace ExOfMethodOveriding
{
    public class Employee
    {
        public string EName;
        public string Gender;

        public virtual void Display()
        {
            System.Console.WriteLine("Employee Name :" + EName);
            System.Console.WriteLine("Gender :" + Gender);
        }
    }

    public class Department : Employee
    {

        public int DeptId;
        public string Dname;

        public override void Display()
        {
            base.Display();
            System.Console.WriteLine("Department ID :" + DeptId);
            System.Console.WriteLine("Department Name :" + Dname);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EName = "Alia";
            emp.Gender = "Female";
            emp.Display();
            Department dp = new Department();
            dp.EName = "Harry";
            dp.Gender = "Male";
            dp.DeptId = 101;
            dp.Dname = "Finance";
            dp.Display();
            System.Console.ReadKey();
        }
    }
}
