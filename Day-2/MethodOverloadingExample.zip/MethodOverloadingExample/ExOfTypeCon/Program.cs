﻿namespace ExOfTypeCon
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            //A variable of "lower numerical data tye" i.e. "short" (2 bytes)
            short a = 100;
            //A variable of "higher numerical data tye" i.e. "int" (4 bytes)
            int b;
            //short to int = lower to higher = implicit casting
            b = a;
            System.Console.WriteLine(a); //Output: 100
            System.Console.WriteLine(b); //Output: 100
            System.Console.ReadKey();
            */

            /*

            //Explicit Type Casting
            //create variable of "int" data type
            int i = 150;
            //create variable of "short" data type
            short j;

            //convert the value from "int" data type "short" data type (higher to lower), using "type casting" concept
            j = (short)i;
            System.Console.WriteLine(i); //Output: 150
            System.Console.WriteLine(j); //Output: 150
            System.Console.ReadKey();

            */

            //parsing Example
            //create variable of "string" data type
            string s = "200";

            //create variable of "int" data type
            double x;
            //convert the value from "string" to "int" data type, using Parsing concept
            x = int.Parse(s); // parsing
          //  x = Convert.ToDouble (s);  //using converion methods
            System.Console.WriteLine(s); //Output: 200
            System.Console.WriteLine(x); //Output: 200
            System.Console.ReadKey();


        }
    }
}

