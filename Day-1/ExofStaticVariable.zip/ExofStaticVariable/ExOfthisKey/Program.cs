﻿namespace ExOfthisKey
{
    class Class1
    {
        public int n = 10;
        public void Display()
        {
            int n = 20;
            System.Console.WriteLine("data member:" + this.n);//Output: 10
            System.Console.WriteLine("local variable:" + n); //Output: 20
            System.Console.WriteLine();
        }
    }
        class Program
    {
        static void Main(string[] args)
        {
                Class1 c1;
                c1 = new Class1();
                c1.Display();
                System.Console.ReadKey();

            }
        }
}
