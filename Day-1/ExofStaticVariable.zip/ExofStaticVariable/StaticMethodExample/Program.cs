﻿namespace StaticMethodExample
{
    class Calculation
    {
        public static void Add(int x, int y) //static method
        {
            int z;
            z = x + y;
            Console.WriteLine("The Value of z is :" + z);
            Console.ReadLine();
        }

        public static void Sub(int x, int y) // statis method
        {
            int z;
            z = x - y;
            Console.WriteLine("The value of z is :" + z);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Calculation.Add(30, 40);
            Calculation.Sub(55, 7);
            Console.ReadKey();

        }
    }
}
