﻿namespace ExofStaticVariable
{
    class Employee
    {
        static int ctr = 10; // shared by all objects
        public void Increment()
        {
            ctr = ctr + 1;
        }
        public void Display()
        {
            Console.WriteLine("Value of Counter Now is  " + ctr);
            Console.ReadLine();
        }
    }

   class Program
    {
        static void Main(string[] args)
        {
            Employee obj1 = new Employee();
            obj1.Increment();
            obj1.Display();

            Employee obj2 = new Employee();
            obj2.Increment();
            obj2.Display();

            Employee obj3 = new Employee();
            obj3.Increment();
            obj3.Display();

        }
    }
}
