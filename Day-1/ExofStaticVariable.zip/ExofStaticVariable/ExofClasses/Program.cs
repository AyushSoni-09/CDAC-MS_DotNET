﻿namespace ExofClasses
{
    class Sample
    {
        public int a, b;
    }


    class Program
    {
        static void Main(string[] args)
        {
            Sample s1; //create reference variable
            s1 = new Sample(); //create object
            s1.a = 10;
            s1.b = 20;

            Sample s2; //create reference variable
            s2 = new Sample(); //create object
            s2.a = 30;
            s2.b = 40;
            System.Console.WriteLine(s1.a);
            System.Console.WriteLine(s1.b);

            System.Console.WriteLine(s2.a);
            System.Console.WriteLine(s2.a);

            System.Console.ReadKey();
        }
    }
}
