﻿namespace ExOfSwitch
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            //Example of Switch case

            //create variables
            int monthnumber = 6;
            string monthname;

            //check the value of monthnumber whether it matches with any one of the following cases
            switch (monthnumber)
            {
                case 1: monthname = "Jan"; break;
                case 2: monthname = "Feb"; break;
                case 3: monthname = "Mar"; break;
                case 4: monthname = "Apr"; break;
                case 5: monthname = "May"; break;
                case 6: monthname = "Jun"; break;
                case 7: monthname = "Jul"; break;
                case 8: monthname = "Aug"; break;
                case 9: monthname = "Sep"; break;
                case 10: monthname = "Oct"; break;
                case 11: monthname = "Nov"; break;
                case 12: monthname = "Dec"; break;
                default: monthname = "unknown"; break;
            }
            System.Console.WriteLine(monthname); 
            System.Console.ReadKey();

            */


            //Example of Break
            //initialization;//condition;//incrementation
            for (int i = 1; i <= 10; i++)
            {
                System.Console.WriteLine(i);
                if (i == 6)
                    break; //stop the loop when "i" value is reached to "6".
            }
            System.Console.ReadKey();

            System.Console.WriteLine("Examples of continue");
            //initialization; condition; incrementation
            for (int j = 1; j <= 10; j++)
            {
                if (j == 6)
                    continue; //skip "6" and go to "7"

                System.Console.WriteLine(j);
            }
            System.Console.ReadKey();


            System.Console.WriteLine("Example of goto Statement");
            System.Console.WriteLine("one");
            System.Console.WriteLine("two");
            //jump to mylabel
            goto mylabel;

            System.Console.WriteLine("three");
            System.Console.WriteLine("four");
            System.Console.WriteLine("five");
        //mylabel starts here
        mylabel:
            System.Console.WriteLine("six");
            System.Console.WriteLine("seven");
            System.Console.ReadKey();

        }
    }
}
