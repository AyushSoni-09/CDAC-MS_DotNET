﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace OpratorsExample
{
   class Program
    {
        static void Main(string[] args)
        {
            //create strings 
            string s1 = "C-DAC";
            string s2 = "Bangalore";
            string s3;

            //concatenate s1 and s2 and store the result in s3
            s3 = s1 + " " + s2;

            System.Console.WriteLine(s1);
            System.Console.WriteLine(s2);
            System.Console.WriteLine(s3);
            System.Console.ReadKey();

            //conditional operator
            // create a variable of "int" data type
            int n = 100;

            //check the condition; store "positive" if the condition is true; store "negative" if the condition is false
            string s = ((n >= 0) ? "positive" : "negative");
            System.Console.WriteLine(s);
            System.Console.ReadKey();


        }
    }
}
