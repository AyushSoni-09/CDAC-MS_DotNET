﻿namespace ExOfConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            //example of Readline
            //  Console.WriteLine("Hello, WelCome to C-DAC");
            // Console.ReadLine();

            //example of Readkey
            //display message 
            /*   System.Console.WriteLine("Hello");

               //wait for pressing any key on the keyboard
               System.Console.ReadKey();

               //display message 

               System.Console.WriteLine("Hello");

               //wait for pressing any key on the keyboard
               System.Console.ReadKey(); */

            //example of Console Clear
            //display message
            System.Console.WriteLine("Hello");
            //wait for pressing any key on the keyboard
            System.Console.ReadKey();
            //clear the screen
            System.Console.Clear();
            //display message
            System.Console.WriteLine("how");
            //wait for pressing any key on the keyboard
            System.Console.ReadKey();
            //clear the screen System.Console.Clear();
            //display message System.Console.WriteLine("are you");
            //wait for pressing any key on the keyboard
            System.Console.ReadKey();


        }
    }
}
