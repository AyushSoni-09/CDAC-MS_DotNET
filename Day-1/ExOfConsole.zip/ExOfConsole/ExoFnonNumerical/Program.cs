﻿namespace ExoFnonNumerical
{
    class Program
    {
        static void Main(string[] args)
        {
            //create variable of "char" data type 
            char ch = 'A';
            //display the value of the variable
            System.Console.WriteLine(ch);
            System.Console.ReadKey();

            //example of string
            //create a variable
            string s = "Hello !! Good Morning";

            //display the value of the variable 
            System.Console.WriteLine(s);
            System.Console.Clear();
            System.Console.WriteLine(s);
            System.Console.WriteLine(s);

            System.Console.ReadKey();
           
              //example of bool
             //create variable of "bool" data type
              bool b = false;
             //display the value of the variable
             System.Console.WriteLine(b);
             System.Console.ReadKey();
                  

        }
    }
}
