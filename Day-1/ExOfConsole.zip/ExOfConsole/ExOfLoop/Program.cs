﻿namespace ExOfLoop
{
    class Program
    {
        static void Main(string[] args)
        {


            /*
             * 
             * System.Console.WriteLine("Example of  while loop");
            //example of while loop
            //initialization
            int i = 1;
            //condition 
            while (i <= 10)
            {
                System.Console.WriteLine(i);
                i++; //incrementation
            }
            System.Console.ReadKey();


            System.Console.WriteLine("Example of Do while loop");
            //Example of Do while loop
            //initialization
            int j = 5;
            do
            {
                System.Console.WriteLine(j); j++; //incrementation
            } while (j <= 20); //condition 
            System.Console.ReadKey();


            */


            /*
            System.Console.WriteLine("Example of for Loop");
            int no;
            Console.WriteLine("Enter A Number");
            no = int.Parse(System.Console.ReadLine());
            Console.WriteLine("You Entered Number " + no.ToString());
            Console.ReadLine();
            int k;
            int nm;
            if (no != 0)
            {
                for (k = 1; k <= 10; k++)
                {
                    nm = no * k;
                    Console.Write(no);
                    Console.Write("*");
                    Console.Write(k);
                    Console.Write("=");
                    Console.WriteLine(nm);
                }
                Console.ReadLine();

            }
            else
            {
                Console.WriteLine("No Entered is Zero Prog Stopped");
                Console.ReadLine();
            }

            */

            System.Console.WriteLine("Example of foreach loop");
            string[] students = new string[] { "Roopa", "Jaya", "Rekha", "Radha" };
            foreach (string student in students)
            {

                System.Console.WriteLine(student);
            }


        }
    }
}
