﻿namespace ExOfDataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            //create variables for all numerical data types
            sbyte a = 10;
            byte b = 20;
            short c = 30;
            ushort d = 40;
            int e = 50;
            uint f = 60;
            long g = 70;
            ulong h = 80;
            float i = 90.23F;
            double j = 100.23489;
            decimal k = 110.882932M;

            //displays the values of all variables

            System.Console.WriteLine(a);
            System.Console.WriteLine(b);
            System.Console.WriteLine(c);
            System.Console.WriteLine(d);
            System.Console.WriteLine(e);
            System.Console.WriteLine(f);
            System.Console.WriteLine(g);
            System.Console.WriteLine(h);
            System.Console.WriteLine(i);
            System.Console.WriteLine(j);
            System.Console.WriteLine(k);
            System.Console.ReadKey();

        }
    }
}
