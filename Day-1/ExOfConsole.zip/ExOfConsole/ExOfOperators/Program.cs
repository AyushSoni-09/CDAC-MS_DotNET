﻿namespace ExOfOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            //create two variables of "double" data type 
            double a = 10, b = 3;

            //addition
            double c = a + b;

            //subtraction
            double d = a - b;

            //multiplication
            double e = a * b;

            //division
            double f = a / b;


            //remainder
            double g = a % b;

            //display all the values 
            System.Console.WriteLine(c);
            System.Console.WriteLine(d);
            System.Console.WriteLine(e);
            System.Console.WriteLine(f);
            System.Console.ReadKey();

            //example of Logical operator
            //create two variables of "long" data type
            long x = 1000, y = 2000;

            //check whether x and y are equal 
            bool b1 = (x == y);

            //check whether x and y are not equal 
            bool b2 = (x != y);

            //check whether x is less than y 
            bool b3 = (x < y);

            //check whether x is greater than y 
            bool b4 = (x > y);

            //check whether x is less than or equal to y
            bool b5 = (x <= y);

            //check whether x is greater than or equal to y 
            bool b6 = (x >= y);

            System.Console.WriteLine(b1);
            System.Console.WriteLine(b2);
            System.Console.WriteLine(b3);
            System.Console.WriteLine(b4);
            System.Console.WriteLine(b5);
            System.Console.WriteLine(b6);



        }
    }
}
