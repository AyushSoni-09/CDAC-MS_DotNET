﻿namespace ExofNestedIf
{
     class Program
    {
        static void Main(string[] args)
        {/*
            //example of IF -Else
            //create variables 
            int n = 150;
            //check whether n is equal to 100
            if (n == 100)
            {
                System.Console.WriteLine("n is equal to 100");
            }
            else
            { 
                System.Console.WriteLine("n is not equal to 100");
            }
            System.Console.ReadKey();

            */

            /*  System.Console.WriteLine("Example of If -Else ");

              //create variables
              int a = 10, b = 20;
              //check which is the big number
              if (a == b)
                  System.Console.WriteLine("a and b are equal");

              else if (a > b)
                  System.Console.WriteLine("a is bigger than b");
              else

              System.Console.WriteLine("b is bigger than a");
              System.Console.ReadKey();

              */

            System.Console.WriteLine("Example of Nested If-Else");
            //create variables
            int c = 150, d = 100;
            string msg;
            //outer if
            if (c >= d)
            {
                //inner if
                if (c > d)
                {
                    msg = "c is greater than d";
                }
                //"else" for "inner if" else
                {
                    msg = "c is equal to d";
                }
            }
            //"else" for "outer if" else
            {
                msg = "c is less than d";
            }
            System.Console.WriteLine(msg); //Output: a is greater than b
            System.Console.ReadKey();


        }
    }
}
