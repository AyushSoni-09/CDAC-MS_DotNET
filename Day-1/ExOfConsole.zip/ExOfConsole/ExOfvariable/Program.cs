﻿namespace ExOfvariable
{
    class Program
    {
        static void Main(string[] args)
        {
            //create a variable
            int x;
            //set value into the variable 
            x = 10;
            //get the value of variable
            System.Console.WriteLine(x);
            //wait for pressing any key on the keyboard
            System.Console.ReadKey();

        }
    }
}
