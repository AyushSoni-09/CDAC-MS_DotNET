﻿
using System.Text;
using System.Diagnostics;
namespace ExOfStrBuild
{
    internal class Program
    {
        static void Main(string[] args)
        {
           string str = " ";
            Stopwatch sw = new Stopwatch();
            sw.Start();
            for (int i = 1; i<= 100000; i++)
            {
                str = str + i;
            }
            sw.Stop();

           StringBuilder sb = new StringBuilder();
            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            for (int i = 1; i<= 10000; i++)
            {
                sb.Append(i);
            }
           sw1.Stop();
            Console.WriteLine("Time taken for string :" +sw.ElapsedMilliseconds);

            Console.WriteLine("Time taken for stringbuilder :" + sw1.ElapsedMilliseconds);
            Console.ReadKey();
        }
    }
}
