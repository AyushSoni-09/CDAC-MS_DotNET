﻿namespace ExOfMathClass
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n = -100; 
            double result;
            //convert the negetive value into positive value
            result = Math.Abs(n);
            Console.WriteLine(n);
            Console.WriteLine(result);

            //get the floor value (without decimal part)
            double n1 = 100.3492;
            result = Math.Floor(n1);
            Console.WriteLine(n1);
            Console.WriteLine(result);

            //get the next number if the first digit in decimal part is greater than or equal to "5"; get the previous number if the first digit in decimal part is less than "5".
            result = Math.Round(n1);

            Console.WriteLine(n);
            Console.WriteLine(result);
            //get the big value among n3 and n4
            double n3 = 100; 
            double n4 = 200;
            result = Math.Max(n3, n4);
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
