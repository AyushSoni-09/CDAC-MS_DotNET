﻿using System.Text;
namespace ExOfStringClass
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //create a string
            string s = "Bangalore";

            //get length (no. of characters in the string)
            int len = s.Length;
            string s2 = s.ToUpper();
            string s3 = s.ToLower();



            //gets the substring from the 4th character -till the end of the string
            string s4 = s.Substring(4);

            int id = 3;

            //display length (no. of characters in the string)
            Console.WriteLine(len);
            Console.WriteLine(s2);
            Console.WriteLine(s3);
            Console.WriteLine(s4);

            //removes part of the string from index 3--till end of the string and return the remaining
            string s5 = s.Remove(id);
            Console.WriteLine(s5);


            String s6 = "xyz";
            //insert "xyz" in Bangalore" at index 3
            string s7 = s.Insert(id, s6);
            Console.WriteLine(s6);

            string str1 = " C-DAC";
            string str2 = "Electronic City";

            //replace "Bangalore" with C-DAC
            string str3 = s.Replace(str1, str2);

            string str4 = "a";
            int ind = s.IndexOf(str4);

            Console.WriteLine(ind);
            Console.ReadKey();
        }
    }
}
